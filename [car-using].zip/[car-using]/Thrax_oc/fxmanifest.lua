fx_version 'adamant'
game 'gta5'
files {

	'data/**/carcols.meta',
	'data/**/carvariations.meta',
	'data/**/handling.meta',
	'data/**/vehiclelayouts.meta',
	'data/**/vehicles.meta',
        'audioconfig/lg62chironpursport_game.dat151.rel',
        'audioconfig/lg62chironpursport_sounds.dat54.rel',
        'sfx/dlc_lg62chironpursport/lg62chironpursport.awc',
        'sfx/dlc_lg62chironpursport/lg62chironpursport_npc.awc',
		'stream/*.yft',
		'stream/*.ytd',
		'vehiclemods/*.yft',
		'vehiclemods/*.ytd',
}
data_file 'VEHICLE_LAYOUTS_FILE' 'data/**/vehiclelayouts.meta'
data_file 'HANDLING_FILE' 'data/**/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'data/**/vehicles.meta'
data_file 'CARCOLS_FILE' 'data/**/carcols.meta'
data_file 'VEHICLE_VARIATION_FILE' 'data/**/carvariations.meta'
data_file 'AUDIO_SYNTHDATA' 'audioconfig/lg62chironpursport_amp.dat'
data_file 'AUDIO_GAMEDATA' 'audioconfig/lg62chironpursport_game.dat151'
data_file 'AUDIO_SOUNDDATA' 'audioconfig/lg62chironpursport_sounds.dat54'
data_file 'AUDIO_WAVEPACK' 'sfx/dlc_lg62chironpursport'