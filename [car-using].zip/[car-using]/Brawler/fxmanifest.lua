fx_version 'adamant'
game 'gta5'
files {

	'handling.meta'
}
data_file 'HANDLING_FILE' 'handling.meta'
